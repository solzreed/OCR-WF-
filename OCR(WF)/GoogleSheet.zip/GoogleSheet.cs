﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Google.GData.Client;
using Google.GData.Extensions;
using Google.GData.Spreadsheets;

namespace OCR_WF_
{
    class GoogleSheet
    {
        private static string userName, password;
        private static ArrayList allWorksheets = new ArrayList();
        private static SpreadsheetsService service = new SpreadsheetsService("test5");
        private static List<string> sheetsName = new List<string>();

        public static string[] sheetArray;

        private static void CallSpreadsheet(SpreadsheetsService service, string dbCode)
        {
            SpreadsheetQuery query = new SpreadsheetQuery("http://spreadsheets.google.com/feeds/spreadsheets/private/full" + dbCode);
            SpreadsheetFeed feed = service.Query(query);

            foreach (SpreadsheetEntry entry in feed.Entries)
            {
                //이 함수는 스프레드시트에 접근 한 상태에서 해당 스프레드시트에 나뉜 워크시트에 접근하는 함수입니다.
                //CallWorksheets(service, entry);
            }
        }
        private static void CallWorksheets(SpreadsheetsService service, SpreadsheetEntry entry)
        {
            AtomLink link = entry.Links.FindService(GDataSpreadsheetsNameTable.WorksheetRel, null);
            WorksheetQuery query = new WorksheetQuery(link.HRef.ToString());
            WorksheetFeed feed = service.Query(query);

            foreach (WorksheetEntry worksheet in feed.Entries)
            {
                allWorksheets.Add(worksheet);
                sheetsName.Add(worksheet.Title.Text);
            }

            sheetArray = sheetsName.ToArray();
        }

        // Read Rows
        // Set Dictionary
        private static Dictionary<string, Dictionary<string, string>> valueTemp = new Dictionary<string, Dictionary<string, string>>();
        private static void RetrieveListFeed(SpreadsheetsService service, WorksheetEntry entry, bool reverseRows)
        {
            valueTemp.Clear();
            AtomLink listFeedLink = entry.Links.FindService(GDataSpreadsheetsNameTable.ListRel, null);

            ListQuery query = new ListQuery(listFeedLink.HRef.ToString());

            if (reverseRows)
            {
                query.OrderByPosition = true;
                query.Reverse = true;
            }
            ListFeed feed = service.Query(query);
        }

        // Send as query
        private static void StructuredQuery(SpreadsheetsService service, WorksheetEntry entry, string queryText)
        {
            AtomLink listFeedLink = entry.Links.FindService(GDataSpreadsheetsNameTable.ListRel, null);

            ListQuery query = new ListQuery(listFeedLink.HRef.ToString());
            query.SpreadsheetQuery = queryText;
            ListFeed feed = service.Query(query);

            foreach (ListEntry worksheetRow in feed.Entries)
            {
                ListEntry.CustomElementCollection elements = worksheetRow.Elements;
                foreach (ListEntry.Custom element in elements)
                {
                    Console.Write(element.Value + "\t");
                }
                Console.WriteLine();
            }
        }

        #region Put , Update Row 
        private static ListEntry InsertRow(SpreadsheetsService service, WorksheetEntry entry)
        {
            AtomLink listFeedLink = entry.Links.FindService(GDataSpreadsheetsNameTable.ListRel, null);

            ListQuery query = new ListQuery(listFeedLink.HRef.ToString());
            ListFeed feed = service.Query(query);

            ListEntry firstRow = feed.Entries[0] as ListEntry;
            ListEntry newRow = new ListEntry();

            foreach (ListEntry.Custom element in firstRow.Elements)
            {
                Console.Write("Enter the value of column \"{0}\": ", element.LocalName);
                String elementValue = Console.ReadLine();

                ListEntry.Custom curElement = new ListEntry.Custom();
                curElement.LocalName = element.LocalName;
                curElement.Value = elementValue;

                newRow.Elements.Add(curElement);
            }

            ListEntry insertedRow = feed.Insert(newRow);
            Console.WriteLine("Successfully inserted new row: \"{0}\"",
                              insertedRow.Content.Content);

            return insertedRow;
        }

        private static ListEntry UpdateRow(SpreadsheetsService service, ListEntry entry)
        {
            ListEntry.Custom firstColumn = entry.Elements[0];

            Console.WriteLine();
            Console.Write("Enter a new value for \"{0}\" (currently \"{1}\"): ",
                          firstColumn.LocalName, firstColumn.Value);
            String newValue = Console.ReadLine();

            firstColumn.Value = newValue;

            ListEntry updatedRow = entry.Update() as ListEntry;

            Console.WriteLine("Successfully updated \"{0}\": \"{1}\"",
                              updatedRow.Elements[0].LocalName, updatedRow.Elements[0].Value);

            return updatedRow;
        }
        #endregion

        #region RetrieveCallFeed
        private static void RetrieveCellFeed(SpreadsheetsService service, WorksheetEntry entry)
        {
            AtomLink cellFeedLink = entry.Links.FindService(GDataSpreadsheetsNameTable.CellRel, null);

            Console.WriteLine();
            Console.WriteLine("This worksheet's cells feed URL is:");
            Console.WriteLine(cellFeedLink.HRef);

            CellQuery query = new CellQuery(cellFeedLink.HRef.ToString());
            CellFeed feed = service.Query(query);

            Console.WriteLine();
            Console.WriteLine("Cells in this worksheet:");
            foreach (CellEntry curCell in feed.Entries)
            {
                Console.WriteLine("Row {0}, column {1}: {2}", curCell.Cell.Row,
                                  curCell.Cell.Column, curCell.Cell.Value);
            }
        }
        #endregion

        #region CallRangeQuery
        private static void CellRangeQuery(SpreadsheetsService service, WorksheetEntry entry)
        {
            AtomLink cellFeedLink = entry.Links.FindService(GDataSpreadsheetsNameTable.CellRel, null);

            CellQuery query = new CellQuery(cellFeedLink.HRef.ToString());
            query.MinimumColumn = 1;
            query.MaximumColumn = 1;
            query.MinimumRow = 2;

            CellFeed feed = service.Query(query);
            Console.WriteLine();
            Console.WriteLine("Cells in column 1:");
            foreach (CellEntry curCell in feed.Entries)
            {
                Console.WriteLine("Row {0}: {1}", curCell.Cell.Row, curCell.Cell.Value);
            }
        }
        #endregion

        #region Update Cell
        private static void UpdateCell(SpreadsheetsService service, WorksheetEntry entry)
        {
            AtomLink cellFeedLink = entry.Links.FindService(GDataSpreadsheetsNameTable.CellRel, null);
            CellQuery query = new CellQuery(cellFeedLink.HRef.ToString());
            Console.WriteLine();

            Console.Write("Row of cell to update? ");
            string row = Console.ReadLine();

            Console.Write("Column of cell to update? ");
            string column = Console.ReadLine();

            query.MinimumRow = query.MaximumRow = uint.Parse(row);
            query.MinimumColumn = query.MaximumColumn = uint.Parse(column);

            CellFeed feed = service.Query(query);
            CellEntry cell = feed.Entries[0] as CellEntry;

            Console.WriteLine();
            Console.WriteLine("Current cell value: {0}", cell.Cell.Value);
            Console.Write("Enter a new value: ");
            string newValue = Console.ReadLine();

            cell.Cell.InputValue = newValue;
            AtomEntry updatedCell = cell.Update();

            Console.WriteLine("Successfully updated cell: {0}", updatedCell.Content.Content);
        }
        #endregion

        private static void Run(string dbCode)
        {
            service.setUserCredentials(userName, password);

            CallSpreadsheet(service, dbCode);

            GoogleData.Instance.IsSessionVaild = true;


            Console.Write("Enter a structured query to execute: ");
            string queryText = Console.ReadLine();
            StructuredQuery(service, entry, queryText);

            // Demonstrate inserting a new row in the worksheet.
            ListEntry insertedEntry = InsertRow(service, entry);

            // Demonstrate updating the inserted row.
            UpdateRow(service, insertedEntry);

            // Demonstrate deleting the entry.
            insertedEntry.Delete();

            // Demonstrate retrieving a cell feed for a worksheet.
            RetrieveCellFeed(service, entry);

            // Demonstrate a cell range query.
            CellRangeQuery(service, entry);

            // Demonstrate updating a single cell.
            UpdateCell(service, entry);
        }

        public static void CallWorkSheetsCellData(int choose)
        {
            int userChoice = choose - 1;
            WorksheetEntry entry = allWorksheets[userChoice] as WorksheetEntry;

            RetrieveListFeed(service, entry, false);
        }


        public static void IntializeGoogleDocs(params string[] args)
        {
            if (args.Length < 2)
            {
                GoogleData.Instance.AddLog("Syntax: <username> <password>");
                return;
            }
            else
            {
                userName = args[0];
                password = args[1];

                Run(args[2]);
            }

        }
        public static ArrayList GetWorkSheetsList()
        {
            return allWorksheets;
        }
    }
}
